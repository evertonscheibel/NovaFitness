import { useState, Suspense, lazy } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import LoadingSpinner from './components/LoadingSpinner';

// Admin Pages
const Dashboard = lazy(() => import('./pages/Dashboard'));
const RegisterForm = lazy(() => import('./pages/RegisterForm'));
const TrainerReview = lazy(() => import('./pages/TrainerReview'));
const StudentList = lazy(() => import('./pages/StudentList'));
const StudentProfile = lazy(() => import('./pages/StudentProfile'));
const StudentEdit = lazy(() => import('./pages/StudentEdit'));
const WorkoutBuilder = lazy(() => import('./pages/WorkoutBuilder'));
const WorkoutList = lazy(() => import('./pages/WorkoutList'));
const WorkoutDetail = lazy(() => import('./pages/WorkoutDetail'));
const FinancialPage = lazy(() => import('./pages/FinancialPage'));
const CheckInPage = lazy(() => import('./pages/CheckInPage'));
const ManagementHub = lazy(() => import('./pages/ManagementHub'));
const ExerciseCatalog = lazy(() => import('./pages/ExerciseCatalog'));
const WorkoutPDF = lazy(() => import('./pages/WorkoutPDF'));

// Student Area Pages
const StudentArea = lazy(() => import('./pages/StudentArea'));
const StudentLogin = lazy(() => import('./pages/StudentLogin'));
const StudentAreaLayout = lazy(() => import('./pages/StudentAreaLayout'));
const StudentAreaDashboard = lazy(() => import('./pages/StudentAreaDashboard'));
const StudentAreaWorkouts = lazy(() => import('./pages/StudentAreaWorkouts'));
const StudentAreaEvolution = lazy(() => import('./pages/StudentAreaEvolution'));

function App() {
    const location = useLocation();
    const isPublicRoute = location.pathname === '/cadastro-aluno' || location.pathname.startsWith('/area-aluno/');

    return (
        <div className="app">
            {!isPublicRoute && (
                <nav className="navbar">
                    <div className="container">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <img src="/logo.png" alt="Logo NovaFitness" style={{ height: '50px' }} />
                            <h1 className="logo">NovaFitness AI Trainer</h1>
                        </div>
                        <div className="nav-links">
                            <Link to="/">Dashboard</Link>
                            <Link to="/management">Gestão</Link>
                            <Link to="/checkin">Check-in</Link>
                        </div>
                    </div>
                </nav>
            )}

            <main className="main-content">
                <Suspense fallback={<LoadingSpinner message="Carregando página..." />}>
                    <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/register" element={<RegisterForm />} />
                        <Route path="/cadastro-aluno" element={<RegisterForm isPublic={true} />} />
                        <Route path="/trainer" element={<TrainerReview />} />
                        <Route path="/students" element={<StudentList />} />
                        <Route path="/student/:id" element={<StudentProfile />} />
                        <Route path="/student/:id/edit" element={<StudentEdit />} />
                        <Route path="/student/:id/workout/new" element={<WorkoutBuilder />} />
                        <Route path="/workouts" element={<WorkoutList />} />
                        <Route path="/workout/:id" element={<WorkoutDetail />} />
                        <Route path="/review/:suggestionId" element={<TrainerReview />} />
                        <Route path="/workout-pdf/:workoutId" element={<WorkoutPDF />} />
                        <Route path="/financial" element={<FinancialPage />} />
                        <Route path="/checkin" element={<CheckInPage />} />
                        <Route path="/management" element={<ManagementHub />} />
                        <Route path="/exercises" element={<ExerciseCatalog />} />
                        <Route path="/area-aluno/:id" element={<StudentArea />} />

                        {/* Student Area Token Routes */}
                        <Route path="/area-aluno/login" element={<StudentLogin />} />
                        <Route path="/area-aluno/token/:token" element={<StudentAreaLayout />}>
                            <Route index element={<StudentAreaDashboard />} />
                            <Route path="treinos" element={<StudentAreaWorkouts />} />
                            <Route path="evolucao" element={<StudentAreaEvolution />} />
                        </Route>
                    </Routes>
                </Suspense>
            </main>

            <footer className="footer">
                <p>&copy; {new Date().getFullYear()} NovaFitness AI Trainer</p>
            </footer>
        </div>
    );
}

export default App;
