import { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { studentAPI, exerciseAPI, trainerAPI } from '../services/api';

function WorkoutBuilder() {
    const { id } = useParams();
    const navigate = useNavigate();
    const location = useLocation(); // Hook para receber estado
    const [student, setStudent] = useState(null);
    const [exercises, setExercises] = useState([]);
    const [loading, setLoading] = useState(true);
    const [trainerName, setTrainerName] = useState('');
    const [workoutData, setWorkoutData] = useState({
        modelo: 'ABC',
        validade_inicio: new Date().toISOString().split('T')[0],
        validade_fim: '',
        observacoes: '',
        sessoes: [
            { dia: 'A', grupos: [], exercicios: [] },
            { dia: 'B', grupos: [], exercicios: [] },
            { dia: 'C', grupos: [], exercicios: [] }
        ]
    });

    const gruposDisponiveis = ['Peito', 'Costas', 'Pernas', 'Ombros', 'Bíceps', 'Tríceps'];

    useEffect(() => {
        loadData();
    }, [id]);

    // Effect para carregar sugestão da IA se houver
    useEffect(() => {
        if (!loading && exercises.length > 0 && location.state?.suggestion) {
            console.log("📥 Carregando sugestão da IA para edição:", location.state.suggestion);
            const { prescricao } = location.state.suggestion.json_sugestao;

            if (prescricao) {
                // Mapear sessões da IA para o formato do Builder
                const mappedSessoes = (prescricao.sessoes || []).map(sessaoIA => {
                    const exerciciosMapeados = (sessaoIA.itens || []).map(item => {
                        // Tentar encontrar ID do exercício pelo nome (Case Insensitive e Trimmed)
                        const exercicioEncontrado = exercises.find(e =>
                            e.nome.toLowerCase().trim() === item.nome_exercicio.toLowerCase().trim() ||
                            item.nome_exercicio.toLowerCase().includes(e.nome.toLowerCase()) // Fallback parcial
                        );

                        return {
                            exercicio_id: exercicioEncontrado ? exercicioEncontrado.id : '',
                            nome: item.nome_exercicio, // Mantém nome original caso não ache ID
                            grupo: exercicioEncontrado ? exercicioEncontrado.grupo_muscular : 'Outros',
                            series: parseInt(item.series) || 3,
                            reps: item.reps || '10',
                            carga: item.carga_sugerida || '',
                            descanso_seg: parseInt(item.descanso_seg) || 60,
                            observacoes: item.observacoes || (exercicioEncontrado ? '' : `Exercício sugerido: ${item.nome_exercicio} (Não encontrado no banco)`)
                        };
                    });

                    // Extrair grupos musculares únicos dessa sessão
                    const gruposUnicos = [...new Set(exerciciosMapeados.map(e => e.grupo))];

                    return {
                        dia: sessaoIA.dia,
                        grupos: gruposUnicos,
                        exercicios: exerciciosMapeados
                    };
                });

                setWorkoutData(prev => ({
                    ...prev,
                    modelo: prescricao.modelo || 'Personalizado', // Ajustar conforme modelo IA
                    observacoes: `Treino gerado por IA. ${prev.observacoes}`,
                    sessoes: mappedSessoes
                }));
            }
        }
    }, [loading, exercises, location.state]);

    const loadData = async () => {
        try {
            const [studentRes, exercisesRes] = await Promise.all([
                studentAPI.getById(id),
                exerciseAPI.getAll()
            ]);
            setStudent(studentRes.data.data.student);
            setExercises(exercisesRes.data.data);
        } catch (error) {
            console.error('Erro ao carregar dados:', error);
            alert('Erro ao carregar dados');
        } finally {
            setLoading(false);
        }
    };

    const handleModeloChange = (e) => {
        const modelo = e.target.value;
        const dias = modelo.split('');
        setWorkoutData({
            ...workoutData,
            modelo,
            sessoes: dias.map(dia => ({ dia, grupos: [], exercicios: [] }))
        });
    };

    const toggleGrupo = (sessaoIdx, grupo) => {
        const newSessoes = [...workoutData.sessoes];
        const grupos = newSessoes[sessaoIdx].grupos;

        if (grupos.includes(grupo)) {
            newSessoes[sessaoIdx].grupos = grupos.filter(g => g !== grupo);
            // Remover exercícios desse grupo
            newSessoes[sessaoIdx].exercicios = newSessoes[sessaoIdx].exercicios.filter(
                ex => !exercises.find(e => e.id === ex.exercicio_id && e.grupo_muscular === grupo)
            );
        } else {
            newSessoes[sessaoIdx].grupos.push(grupo);
        }

        setWorkoutData({ ...workoutData, sessoes: newSessoes });
    };

    const addExercicio = (sessaoIdx, grupo) => {
        const newSessoes = [...workoutData.sessoes];
        newSessoes[sessaoIdx].exercicios.push({
            exercicio_id: '',
            nome: '',
            grupo,
            series: 4,
            reps: '8-12',
            carga: '',
            descanso_seg: 90,
            observacoes: ''
        });
        setWorkoutData({ ...workoutData, sessoes: newSessoes });
    };

    const updateExercicio = (sessaoIdx, exIdx, field, value) => {
        const newSessoes = [...workoutData.sessoes];
        newSessoes[sessaoIdx].exercicios[exIdx][field] = value;

        if (field === 'exercicio_id') {
            const exercise = exercises.find(e => e.id === value);
            if (exercise) {
                newSessoes[sessaoIdx].exercicios[exIdx].nome = exercise.nome;
            }
        }

        setWorkoutData({ ...workoutData, sessoes: newSessoes });
    };

    const removeExercicio = (sessaoIdx, exIdx) => {
        const newSessoes = [...workoutData.sessoes];
        newSessoes[sessaoIdx].exercicios.splice(exIdx, 1);
        setWorkoutData({ ...workoutData, sessoes: newSessoes });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!trainerName.trim()) {
            alert('Por favor, informe o nome do treinador');
            return;
        }

        if (!workoutData.validade_fim) {
            alert('Por favor, defina a data de término da vigência');
            return;
        }

        try {
            await trainerAPI.createManual({
                aluno_id: id,
                ...workoutData,
                treinador: trainerName
            });
            alert('Treino criado com sucesso! ✅');
            navigate(`/student/${id}`);
        } catch (error) {
            console.error('Erro ao criar treino:', error);
            alert('Erro ao criar treino: ' + (error.response?.data?.message || error.message));
        }
    };

    if (loading || !student) {
        return <div className="container"><div className="loading">⏳ Carregando...</div></div>;
    }

    return (
        <div className="container">
            <div className="dashboard-header">
                <h2>🏋️ Criar Treino Manual - {student.nome}</h2>
            </div>

            <form onSubmit={handleSubmit} className="card">
                <div className="form-row">
                    <div className="form-group">
                        <label>Nome do Treinador *</label>
                        <input
                            type="text"
                            value={trainerName}
                            onChange={(e) => setTrainerName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Modelo de Treino *</label>
                        <select value={workoutData.modelo} onChange={handleModeloChange} required>
                            <option value="AB">AB (2 dias)</option>
                            <option value="ABC">ABC (3 dias)</option>
                            <option value="ABCD">ABCD (4 dias)</option>
                            <option value="ABCDE">ABCDE (5 dias)</option>
                        </select>
                    </div>
                </div>

                <div className="form-row">
                    <div className="form-group">
                        <label>Início da Vigência *</label>
                        <input
                            type="date"
                            value={workoutData.validade_inicio}
                            onChange={(e) => setWorkoutData({ ...workoutData, validade_inicio: e.target.value })}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Fim da Vigência *</label>
                        <input
                            type="date"
                            value={workoutData.validade_fim}
                            onChange={(e) => setWorkoutData({ ...workoutData, validade_fim: e.target.value })}
                            required
                        />
                    </div>
                </div>

                {workoutData.sessoes.map((sessao, sessaoIdx) => (
                    <div key={sessao.dia} className="card" style={{ marginTop: '20px', background: '#f8f9fa' }}>
                        <h3>Treino {sessao.dia}</h3>

                        <div style={{ marginBottom: '15px' }}>
                            <label><strong>Grupos Musculares:</strong></label>
                            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '10px' }}>
                                {gruposDisponiveis.map(grupo => (
                                    <label key={grupo} style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                                        <input
                                            type="checkbox"
                                            checked={sessao.grupos.includes(grupo)}
                                            onChange={() => toggleGrupo(sessaoIdx, grupo)}
                                        />
                                        {grupo}
                                    </label>
                                ))}
                            </div>
                        </div>

                        {sessao.grupos.map(grupo => (
                            <div key={grupo} style={{ marginTop: '20px', padding: '15px', background: 'white', borderRadius: '8px' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <h4>💪 {grupo}</h4>
                                    <button
                                        type="button"
                                        onClick={() => addExercicio(sessaoIdx, grupo)}
                                        className="btn btn-sm btn-secondary"
                                    >
                                        ➕ Adicionar Exercício
                                    </button>
                                </div>

                                {sessao.exercicios
                                    .map((ex, exIdx) => ({ ex, exIdx }))
                                    .filter(({ ex }) => ex.grupo === grupo)
                                    .map(({ ex, exIdx }) => (
                                        <div key={exIdx} style={{ marginTop: '10px', padding: '10px', background: '#f8f9fa', borderRadius: '4px' }}>
                                            <div className="form-row">
                                                <div className="form-group" style={{ flex: 2 }}>
                                                    <label>Exercício</label>
                                                    <select
                                                        value={ex.exercicio_id}
                                                        onChange={(e) => updateExercicio(sessaoIdx, exIdx, 'exercicio_id', e.target.value)}
                                                        required
                                                    >
                                                        <option value="">Selecione...</option>
                                                        {exercises
                                                            .filter(e => e.grupo_muscular === grupo)
                                                            .map(e => (
                                                                <option key={e.id} value={e.id}>{e.nome}</option>
                                                            ))}
                                                    </select>
                                                    {ex.exercicio_id && exercises.find(e => e.id === ex.exercicio_id)?.image_url && (
                                                        <div style={{ marginTop: '5px' }}>
                                                            <img
                                                                src={exercises.find(e => e.id === ex.exercicio_id).image_url}
                                                                alt="Exercício"
                                                                style={{ maxWidth: '100px', maxHeight: '100px', borderRadius: '4px', border: '1px solid #ddd' }}
                                                            />
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group">
                                                    <label>Séries</label>
                                                    <input
                                                        type="number"
                                                        value={ex.series}
                                                        onChange={(e) => updateExercicio(sessaoIdx, exIdx, 'series', parseInt(e.target.value))}
                                                        min="1"
                                                        required
                                                    />
                                                </div>
                                                <div className="form-group">
                                                    <label>Reps</label>
                                                    <input
                                                        type="text"
                                                        value={ex.reps}
                                                        onChange={(e) => updateExercicio(sessaoIdx, exIdx, 'reps', e.target.value)}
                                                        placeholder="8-12"
                                                        required
                                                    />
                                                </div>
                                                <div className="form-group">
                                                    <label>Carga</label>
                                                    <input
                                                        type="text"
                                                        value={ex.carga}
                                                        onChange={(e) => updateExercicio(sessaoIdx, exIdx, 'carga', e.target.value)}
                                                        placeholder="20kg"
                                                    />
                                                </div>
                                                <div className="form-group">
                                                    <label>Descanso (s)</label>
                                                    <input
                                                        type="number"
                                                        value={ex.descanso_seg}
                                                        onChange={(e) => updateExercicio(sessaoIdx, exIdx, 'descanso_seg', parseInt(e.target.value))}
                                                        min="30"
                                                    />
                                                </div>
                                                <div style={{ display: 'flex', alignItems: 'flex-end' }}>
                                                    <button
                                                        type="button"
                                                        onClick={() => removeExercicio(sessaoIdx, exIdx)}
                                                        className="btn btn-sm"
                                                        style={{ background: '#dc3545', color: 'white' }}
                                                    >
                                                        🗑️
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                            </div>
                        ))}
                    </div>
                ))}

                <div className="form-group" style={{ marginTop: '20px' }}>
                    <label>Observações Gerais</label>
                    <textarea
                        value={workoutData.observacoes}
                        onChange={(e) => setWorkoutData({ ...workoutData, observacoes: e.target.value })}
                        rows="3"
                        placeholder="Observações para o aluno..."
                    />
                </div>

                <div className="form-row" style={{ marginTop: '20px' }}>
                    <button type="button" onClick={() => navigate(`/student/${id}`)} className="btn">
                        Cancelar
                    </button>
                    <button type="submit" className="btn btn-primary">
                        💾 Salvar Treino
                    </button>
                </div>
            </form>
        </div>
    );
}

export default WorkoutBuilder;
